import unittest
import pandas
import pytest
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql import Row
# from helper.helper import *
from helper.helper.helper import *
class TestReadOrWriteFiles(unittest.TestCase):
    def setUp(self):
        self.spark_read_or_write = SparkSession.builder.appName("TestReadOrWriteFiles").config("spark.jars.packages", "com.crealytics:spark-excel_2.12:3.3.3_0.20.3").getOrCreate()
        self.pandas_df = pandas.DataFrame({'Name': ['Alice', 'Bob'], 'Age': [25, 30]})
        self.data = [("Alice", 25), ("Bob", 30), ("Carol", 35)]
        self.spark_df = self.spark_read_or_write.createDataFrame(self.data, ["Name", "Age"])
        self.json_data = {"name":"Alice", "age": 23, "class": "BE"}

    def tearDown(self):
        self.spark_read_or_write.stop()

    def test_write_csv_file_pandas(self):
        actual_result = ReadOrWriteFiles(user_id="20240710").write_csv(engine="pandas", file_name="students_write.csv", dataframe=self.pandas_df)
        self.assertTrue(actual_result)
    
    def test_write_csv_file_pandas_by_sending_spark_dataframe(self):
        with pytest.raises(Exception) as test_func:
            ReadOrWriteFiles(user_id="20240710").write_csv(engine="pandas", file_name="students.xlsx", dataframe=self.spark_df)
        self.assertEqual('The provided DataFrame is not a pandas DataFrame. Please provide a pandas DataFrame.', str(test_func.value))

    def test_write_csv_file_pandas_with_kwargs(self):
        config={"sep":"|"}
        actual_result = ReadOrWriteFiles(user_id="20240710").write_csv(engine="pandas", file_name="students_write.csv", dataframe=self.pandas_df, **config)
        self.assertTrue(actual_result)

    def test_write_xls_file_pandas(self):
        actual_result = ReadOrWriteFiles(user_id="20240710").write_excel(engine="pandas", file_name="students.xls", dataframe=self.pandas_df)
        self.assertTrue(actual_result)

    def test_write_xlsx_file_pandas(self):
        actual_result = ReadOrWriteFiles(user_id="20240710").write_excel(engine="pandas", file_name="students.xlsx", dataframe=self.pandas_df)
        self.assertTrue(actual_result)

    def test_read_csv_pandas(self):
        ReadOrWriteFiles(user_id="20240710").write_csv(engine="pandas", file_name="students_read.csv", dataframe=self.pandas_df)
        actual_result = ReadOrWriteFiles(user_id="20240710").read_csv(engine="pandas", file_name="students_read.csv")
        expected_result = [['Alice', 25], ['Bob', 30]]
        self.assertEqual(expected_result, actual_result.values.tolist())

    def test_read_csv_pandas_by_giving_excel_file_as_input(self):
        ReadOrWriteFiles(user_id="20240710").write_excel(engine="pandas", file_name="students_read.xls", dataframe=self.pandas_df)
        with pytest.raises(Exception) as test_func:
            ReadOrWriteFiles(user_id="20240710").read_csv(engine="pandas", file_name="students_read.xls")
        self.assertEqual("UnicodeDecodeError: 'utf-8' codec can't decode byte 0x9d in position 11: invalid start byte", str(test_func.value()))

    def test_read_xls_pandas(self):
        ReadOrWriteFiles(user_id="20240710").write_excel(engine="pandas", file_name="students.xls", dataframe=self.pandas_df)
        actual_result = ReadOrWriteFiles(user_id="20240710").read_excel(engine="pandas", file_name="students.xls")
        expected_result = [['Alice', 25], ['Bob', 30]]
        self.assertEqual(expected_result, actual_result.values.tolist())

    def test_read_xls_pandas_with_kwargs(self):
        ReadOrWriteFiles(user_id="20240710").write_excel(engine="pandas", file_name="students.xls", dataframe=self.pandas_df)
        config = {
                    "sheet_name": "Sheet1",
                    "usecols": "A:C",
                    "skiprows": 1
                }
        actual_result = ReadOrWriteFiles(user_id="20240710").read_excel(engine="pandas", file_name="students.xls", **config)
        expected_result = [['Bob', 30]]
        self.assertEqual(expected_result, actual_result.values.tolist())

    def test_read_xlsx_pandas(self):
        ReadOrWriteFiles(user_id="20240710").write_excel(engine="pandas", file_name="students.xlsx", dataframe=self.pandas_df)
        actual_result = ReadOrWriteFiles(user_id="20240710").read_excel(engine="pandas", file_name="students.xlsx")
        expected_result = [['Alice', 25], ['Bob', 30]]
        self.assertEqual(expected_result, actual_result.values.tolist())
    
    def test_read_xlsx_pandas_with_kwargs(self):
        ReadOrWriteFiles(user_id="20240710").write_excel(engine="pandas", file_name="students.xlsx", dataframe=self.pandas_df)
        config = {
                    "sheet_name": "Sheet1",
                    "usecols": "A:C",
                    "skiprows": 1
                }
        actual_result = ReadOrWriteFiles(user_id="20240710").read_excel(engine="pandas", file_name="students.xlsx", **config)
        expected_result = [['Bob', 30]]
        self.assertEqual(expected_result, actual_result.values.tolist())

    def test_write_csv_file_spark(self):
        actual_result = ReadOrWriteFiles(user_id="20240710").write_csv(engine="spark", file_name="students.csv", dataframe=self.spark_df)
        self.assertTrue(actual_result)
    
    def test_write_csv_file_spark_with_kwargs(self):
        config={"sep":"|"}
        actual_result = ReadOrWriteFiles(user_id="20240710").write_csv(engine="spark", file_name="students.csv", dataframe=self.spark_df, **config)
        self.assertTrue(actual_result)

    def test_write_xls_file_spark(self):
        actual_result = ReadOrWriteFiles(user_id="20240710").write_excel(engine="spark", file_name="students.xls", dataframe=self.spark_df)
        self.assertTrue(actual_result)

    def test_write_xlsx_file_spark(self):
        actual_result = ReadOrWriteFiles(user_id="20240710").write_excel(engine="spark", file_name="students.xlsx", dataframe=self.spark_df)
        self.assertTrue(actual_result)

    def test_write_xlsx_file_spark_by_sending_pandas_dataframe(self):
        with pytest.raises(Exception) as test_func:
            ReadOrWriteFiles(user_id="20240710").write_excel(engine="spark", file_name="students.xlsx", dataframe=self.pandas_df)
        self.assertEqual('The provided DataFrame is not a Spark DataFrame. Please provide a Spark DataFrame.', str(test_func.value))

    def test_read_csv_spark(self):
        ReadOrWriteFiles(user_id="20240710").write_csv(engine="spark", file_name="students.csv", dataframe=self.spark_df)
        dataframe = ReadOrWriteFiles(user_id="20240710").read_csv(engine="spark", file_name="students.csv")
        actual_result = dataframe.collect()
        expected_result = [['Alice', '25'], ['Bob', '30'], ['Carol', '35']]
        self.assertEqual(expected_result, [list(row) for row in actual_result])

    def test_read_xls_spark(self):
        ReadOrWriteFiles(user_id="20240710").write_excel(engine="spark", file_name="students.xls", dataframe=self.spark_df)
        dataframe = ReadOrWriteFiles(user_id="20240710").read_excel(engine="spark", file_name="students.xls")
        actual_result = dataframe.collect()
        expected_result = [['Alice', '25'], ['Bob', '30'], ['Carol', '35']]
        self.assertEqual(expected_result, [list(row) for row in actual_result])

    def test_read_xls_spark_with_kwargs(self):
        ReadOrWriteFiles(user_id="20240710").write_excel(engine="spark", file_name="students.xls", dataframe=self.spark_df)
        config={"dataAddress": "'Sheet1'!A1:B2"}
        dataframe = ReadOrWriteFiles(user_id="20240710").read_excel(engine="spark", file_name="students.xls", **config)
        actual_result = dataframe.collect()
        expected_result = [['Alice', '25']]
        self.assertEqual(expected_result, [list(row) for row in actual_result])

    def test_read_xlsx_spark(self):
        ReadOrWriteFiles(user_id="20240710").write_excel(engine="spark", file_name="students.xlsx", dataframe=self.spark_df)
        dataframe = ReadOrWriteFiles(user_id="20240710").read_excel(engine="spark", file_name="students.xlsx")
        actual_result = dataframe.collect()
        expected_result = [['Alice', '25'], ['Bob', '30'], ['Carol', '35']]
        self.assertEqual(expected_result, [list(row) for row in actual_result])

    def test_read_xlsx_spark_with_kwargs(self):
        ReadOrWriteFiles(user_id="20240710").write_excel(engine="spark", file_name="students.xlsx", dataframe=self.spark_df)
        config={"dataAddress": "'Sheet1'!A1:B2"}
        dataframe = ReadOrWriteFiles(user_id="20240710").read_excel(engine="spark", file_name="students.xlsx", **config)
        actual_result = dataframe.collect()
        expected_result = [['Alice', '25']]
        self.assertEqual(expected_result, [list(row) for row in actual_result])

    def test_read_json(self):
        ReadOrWriteFiles(user_id="20240710").write_json(file_name="students.json", json_data=self.json_data)
        actual_result = ReadOrWriteFiles(user_id="20240710").read_json(file_name="students.json")
        expected_result = {'name': 'Alice', 'age': 23, 'class': 'BE'}
        self.assertEqual(actual_result, expected_result)

    def test_write_json(self):
        actual_result = ReadOrWriteFiles(user_id="20240710").write_json(file_name="students_data.json", json_data=self.json_data)
        self.assertTrue(actual_result)


class TestJobArguments(unittest.TestCase):
    def test_get(self):
        config_dict = {"__read_file__": {"mode": "append"}}
        actual_result = JobArguments(config_dict).get()
        self.assertEqual(config_dict, actual_result)

    def test_get_with_key(self):
        config_dict = {"__read_file__": {"mode": "append"}, "__read_table__": {"mode": "append"}}
        actual_result = JobArguments(config_dict).get("__read_table__")
        expected_result = {"__read_table__": {"mode": "append"}}
        self.assertEqual(expected_result, actual_result)

    def test_update(self):
        config_dict = {"__read_file__": {"mode": "append"}}
        actual_result = JobArguments(config_dict).update("__config__", "true")
        expected_result = {"__read_file__": {"mode": "append"}, "__config__":"true"}
        self.assertEqual(expected_result, actual_result)

    def test_update_existing_data(self):
        config_dict = {"__read_file__": {"mode": "append"}}
        actual_result = JobArguments(config_dict).update("__read_file__", {"mode": "overwrite"})
        expected_result = {"__read_file__": {"mode": "overwrite"}}
        self.assertEqual(expected_result, actual_result)

    def test_create(self):
        config_dict = {}
        actual_result = JobArguments(config_dict).create("config", "true")
        expected_result = {"config": "true"}
        self.assertEqual(expected_result, actual_result)

    def test_create_if_config_key_already_present(self):
        config_dict = {"__config__":"true"}
        with pytest.raises(Exception) as test:
            JobArguments(config_dict).create("__config__", "false")
        self.assertEqual("The key __config__ already exists, please use a different key.", str(test.value))

    def test_delete(self):
        config_dict = {"__read_file__": {"mode": "append"}, "__config__":"true"}
        actual_result = JobArguments(config_dict).delete("__config__")
        expected_result = {"__read_file__": {"mode": "append"}}
        self.assertEqual(expected_result, actual_result)

    def test_delete_with_non_existing_key(self):
        config_dict = {"__read_file__": {"mode": "append"}, "__config__":"true"}
        with pytest.raises(Exception) as test:
            JobArguments(config_dict).delete("__config")
        self.assertEqual("'__config'", str(test.value))

class TestDataframeInformation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spark_dataframe_information = SparkSession.builder.appName("TestDataframeInfo").getOrCreate()

    @classmethod
    def tearDownClass(cls):
        cls.spark_dataframe_information.stop()
    
    def test_get_without_id_and_alias(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        actual_result = DataframeInformation(config_dict).get()
        expected_result = config_dict
        self.assertEqual(expected_result, actual_result)

    def test_get_with_id(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        actual_result = DataframeInformation(config_dict).get(id="11223344")
        expected_result = df
        self.assertEqual(expected_result.values.tolist(), actual_result.values.tolist())

    def test_get_with_alias(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        actual_result = DataframeInformation(config_dict).get(alias="teachers")
        expected_result = df
        self.assertEqual(expected_result.values.tolist(), actual_result.values.tolist())

    def test_get_with_non_existing_alias(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        with pytest.raises(Exception) as test:
            DataframeInformation(config_dict).get(alias="course")
        self.assertEqual("Alias 'course' not found.", str(test.value))

    def test_get_with_non_existing_id(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        with pytest.raises(Exception) as test:
            DataframeInformation(config_dict).get(id="23")
        self.assertEqual("ID '23' not found.", str(test.value))

    def test_create(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        actual_result = DataframeInformation().create(id="123456", alias="sample", dataframe=df)
        self.assertTrue(actual_result)

    def test_create_with_existing_id(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        with pytest.raises(Exception) as test:
            DataframeInformation(config_dict).create(id="11223344", alias="sample", dataframe=df)
        self.assertEqual("The ID '11223344' already exists, please use a different ID.", str(test.value))

    def test_create_with_existing_alias(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        with pytest.raises(Exception) as test:
            DataframeInformation(config_dict).create(id="11223341", alias="students", dataframe=df)
        self.assertEqual("The alias 'students' already exists, please use a different alias.", str(test.value))

    def test_update(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        data1 = {'name': ["arunraj", "ram"], 'age': [30, 40]}
        df1 = pandas.DataFrame(data1)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        actual_result = DataframeInformation(config_dict).update(id="11223344", alias="students", dataframe=df1)
        self.assertTrue(actual_result)

    def test_delete_with_alias(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        actual_result = DataframeInformation(config_dict).delete(alias="students")
        self.assertTrue(actual_result)

    def test_delete_with_id(self):
        data = {'name': ["arun", "ram"], 'age': [3, 4]}
        df = pandas.DataFrame(data)
        config_dict = {"11223344": {"df": df, "alias": "students"}, 
                       "55667788": {"df": df, "alias": "teachers"}}
        actual_result = DataframeInformation(config_dict).delete(alias= "students", id="11223344")
        self.assertTrue(actual_result)

    def test_convert_to_pandas_with_input_as_spark_dataframe(self):
        data = [
            Row(id=1, name="John", age=25),
            Row(id=2, name="Alice", age=30),
            Row(id=3, name="Bob", age=22)
        ]
        schema = ["id", "name", "age"]
        df = self.spark_dataframe_information.createDataFrame(data, schema=schema)
        actual_result = DataframeInformation().convert_to_pandas(df)
        data = {'id': [1,2,3] , 'name': ["John", "Alice", "Bob"], 'age': [25, 30, 22]}
        expected_result = pandas.DataFrame(data)
        self.assertTrue(expected_result.equals(actual_result))
        self.assertTrue(isinstance(actual_result, pandas.DataFrame))

    def test_convert_to_spark_with_input_as_pandas_dataframe(self):
        data = {'id': [1,2,3] , 'name': ["John", "Alice", "Bob"], 'age': [25, 30, 22]}
        df = pandas.DataFrame(data)
        actual_result = DataframeInformation().convert_to_spark(df)
        self.assertTrue(isinstance(actual_result, pyspark.sql.dataframe.DataFrame))

    def test_convert_to_pandas_with_input_as_pandas_dataframe(self):
        data = {'id': [1,2,3] , 'name': ["John", "Alice", "Bob"], 'age': [25, 30, 22]}
        df = pandas.DataFrame(data)
        # <class 'pandas.core.frame.DataFrame'>
        actual_result = DataframeInformation().convert_to_pandas(df)
        data = {'id': [1,2,3] , 'name': ["John", "Alice", "Bob"], 'age': [25, 30, 22]}
        expected_result = pandas.DataFrame(data)
        self.assertTrue(expected_result.equals(actual_result))
        self.assertTrue(isinstance(actual_result, pandas.DataFrame))

    def test_convert_to_spark_with_input_as_spark_dataframe(self):
        data = [
            Row(id=1, name="John", age=25),
            Row(id=2, name="Alice", age=30),
            Row(id=3, name="Bob", age=22)
        ]
        schema = ["id", "name", "age"]
        df = self.spark_dataframe_information.createDataFrame(data, schema=schema)
        actual_result = DataframeInformation().convert_to_spark(df)
        self.assertTrue(isinstance(actual_result, pyspark.sql.dataframe.DataFrame))
